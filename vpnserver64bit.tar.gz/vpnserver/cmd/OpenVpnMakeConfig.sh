#!/bin/sh
cd /vpnserver
./vpncmd <<EOF
1


OpenVpnMakeConfig
config
EOF
