#!/bin/sh
cd /vpnserver
./vpncmd <<EOF
1

DEFAULT
SessionList
exit
EOF