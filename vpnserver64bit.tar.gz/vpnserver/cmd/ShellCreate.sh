#!/bin/sh
cd /vpnserver
echo $1 $2 >> /vpnserver/user