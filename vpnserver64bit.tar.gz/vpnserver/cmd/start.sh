#!/bin/sh
cd /vpnserver
./cmdtool
